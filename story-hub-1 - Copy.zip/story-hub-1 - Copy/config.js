import firebase from 'firebase'
require("@firebase/firestore")